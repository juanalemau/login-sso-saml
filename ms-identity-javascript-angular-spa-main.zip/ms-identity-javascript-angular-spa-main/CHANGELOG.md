# CHANGELOG

## 05/14/2021

* Bumped msal-browser and msal-angular

## 04/22/2021

* Bumped msal-browser and msal-angular
* Fixed type error on home.component.ts
* Replaced logout with logoutPopup and logoutRedirect

## 12/04/2020

* Initial sample.
